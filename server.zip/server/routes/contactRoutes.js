import express from "express";
import Contact from "../models/Contact.js";

const router = express.Router();


// CREATE CONTACT
router.post("/", async (req, res) => {
  try {
    const { userId, name, email, phone, notes, tags } = req.body;

    const newContact = new Contact({
      userId,
      name,
      email,
      phone,
      notes,
      tags
    });

    const savedContact = await newContact.save();

    res.status(201).json(savedContact);

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// GET CONTACTS BY USER
router.get("/:userId", async (req, res) => {
  try {
    const contacts = await Contact.find({ userId: req.params.userId });

    res.json(contacts);

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// UPDATE CONTACT
router.put("/:id", async (req, res) => {
  try {
    const updatedContact = await Contact.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );

    if (!updatedContact) {
      return res.status(404).json({ message: "Contact not found" });
    }

    res.json(updatedContact);

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// DELETE CONTACT
router.delete("/:id", async (req, res) => {
  try {
    const contact = await Contact.findByIdAndDelete(req.params.id);

    if (!contact) {
      return res.status(404).json({ message: "Contact not found" });
    }

    res.json({ message: "Contact deleted successfully" });

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


// SEARCH CONTACT
router.get("/search/:name", async (req, res) => {
  try {
    const contacts = await Contact.find({
      name: { $regex: req.params.name, $options: "i" }
    });

    res.json(contacts);

  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});


export default router;