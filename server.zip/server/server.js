// server.js - ConnectHub Backend

// Step 1: Import required packages
import express from "express";
import mongoose from "mongoose";
import cors from "cors";
import dotenv from "dotenv";

// Step 2: Load environment variables from .env
dotenv.config();

// Step 3: Create Express app and define PORT
const app = express();
const PORT = process.env.PORT || 5000;

// Step 4: Add middleware
app.use(cors());
app.use(express.json()); // allows reading JSON request bodies

// Step 4.1: Connect Auth Routes
import authRoutes from "./routes/authRoutes.js";
app.use("/api/auth", authRoutes);

// Step 4.2: Connect Contact Routes
import contactRoutes from "./routes/contactRoutes.js";
app.use("/api/contacts", contactRoutes);

// Step 5: Connect to MongoDB (Mongoose 7+)
mongoose.connect(process.env.MONGO_URI)  // <-- no extra options needed
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.log("MongoDB connection error:", err));

// Step 6: Test route
app.get("/", (req, res) => {
  res.send("Backend is running");
});

// Step 7: Start the server
app.listen(PORT, () => {
  console.log(`Server running on PORT ${PORT}`);
});